def koon(a):
    print('koon')
    if a < 10:
        print('a is smaller than 10')
    
def kir():
    print('kir')
    kir1()

def kir1():
    print('kir1')

def koon_boos(b):
    a = 1000
    if b > 10:
        print(a-12+b)
    else:
        while b >= 0:
            print("koon_boosidam",b)
            b -= 1

def run():

    kir()
    koon(2)
    koon_boos(10)

    
if __name__ == '__main__':
    import coverage
    
    cov = coverage.Coverage()
    cov.start()
    run()
    cov.stop()
    cov.save()
    cov.html_report()