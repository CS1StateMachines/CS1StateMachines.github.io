import gamify
import unittest



class TestBasicCases(unittest.TestCase):

    def setUp(self):
        pass
        
    def test_init_called_outside_main_health(self):
        self.assertEqual(gamify.get_cur_health(), 0)
        
    def test_init_called_outside_main_hedon(self):
        self.assertEqual(gamify.get_cur_hedons(), 0)    
        
if __name__ == '__main__':
    unittest.main()