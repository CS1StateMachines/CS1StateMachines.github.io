import unittest
#import pep8  # from the current directory
import credit
import importlib
import sys

class TestSimplePurchase(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')

    def test_single_purchase(self):
        credit.purchase(30,2,3,'Canada')
        self.assertEqual(credit.amount_owed(2,3),30)

    def test_two_purchases_multi_country(self):
        credit.purchase(30,2,3,'Canada')
        credit.purchase(20,3,3,'USA')
        self.assertEqual(credit.amount_owed(4,3),50)
    def test_two_purchases_smae_country(self):
        credit.purchase(30,2,3,'Canada')
        credit.purchase(20,3,3,'Canada')
        self.assertEqual(credit.amount_owed(3,3),50)

class TestNoBackDating(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')

    def test_purchase_purchase(self):
        credit.purchase(30,2,3,'Canada')
        self.assertEqual(credit.purchase(20,1,3,'Canada').lower(),'ERROR'.lower())

    def test_purchase_pay(self):
        credit.purchase(30,2,3,'Canada')
        self.assertEqual(credit.pay_bill(20,1,3).lower(),'ERROR'.lower()) #ERROR

    def test_purchase_balance(self):
        credit.purchase(30,2,3,'Canada')
        self.assertEqual(credit.amount_owed(1,3).lower(),'ERROR'.lower()) #ERROR

    def test_balance_balance(self):
        credit.amount_owed(2,3)
        self.assertEqual(credit.amount_owed(1,3).lower(),'ERROR'.lower()) #ERROR

    def test_purchase_balance2(self):
        credit.purchase(21,1,3,'UK')
        self.assertEqual(credit.amount_owed(1,2).lower(),'ERROR'.lower()) #ERROR

    def test_same_day_works(self):
        credit.purchase(21,1,3,'UK')
        credit.purchase(10,1,3,'UK')
        self.assertEqual(credit.amount_owed(1,3),31)


class TestSinglePurchaseInterest(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')
        credit.purchase(40, 2,3,'Canada')

    def test_no_interest_month_of_purchase(self):
        self.assertEqual(credit.amount_owed(31,3),40)
    
    def test_no_interest_month_of_billing(self):
        self.assertEqual(credit.amount_owed(30,4),40)

    def test_interest_after_billing_month(self):
        self.assertAlmostEqual(credit.amount_owed(1,5),40*1.05)
    def test_compound_interest(self):
        self.assertAlmostEqual(credit.amount_owed(1,6),40*1.05*1.05)


class TestSimplePayments(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')
        credit.purchase(30, 2,3,'Canada')

    def test_full_pay_before_interest(self):
        credit.pay_bill(30,30,4)
        self.assertAlmostEqual(credit.amount_owed(30,4),0)
    def test_partial_pay_before_interest(self):
        credit.pay_bill(20,30,4)
        self.assertAlmostEqual(credit.amount_owed(30,4),10)
    def test_can_make_purchase_after_payment(self):
        credit.pay_bill(20,30,4)
        credit.purchase(15,30,4,'Canada')
        self.assertAlmostEqual(credit.amount_owed(30,4),25)



if __name__ == '__main__':
    unittest.main()
