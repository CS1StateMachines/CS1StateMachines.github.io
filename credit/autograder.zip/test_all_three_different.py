import unittest
#import pep8  # from the current directory
import credit
import importlib
import sys

class TestAllThreeDiff(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            pass

    def tearDown(self):
        pass

    def test_null_as_first(self):
        '''ensuring if the first variable is None at start (likely case) the code still works'''
        self.assertTrue(credit.all_three_different(None, 'a','b'))

    def test_a_b_a(self):
        self.assertFalse(credit.all_three_different('a','b','a'))

    def test_a_a_b(self):
        self.assertFalse(credit.all_three_different('a','a','b'))

    def test_a_b_b(self):
        self.assertFalse(credit.all_three_different('a','b','b'))
    def test_a_b_c(self):
        self.assertTrue(credit.all_three_different('a','b','c'))
    def test_a_a_a(self):
        self.assertFalse(credit.all_three_different('a','a','a'))

class TestPurcahseDiffCountries(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')
        credit.purchase(30,2,3,'Canada')
        credit.purchase(20,3,3,'USA')

    def tearDown(self):
        pass

    def test_no_purchase_after_disable(self):
        credit.purchase(10,4,3,'UK')
        self.assertEqual(credit.purchase(10,5,3,'Canada').lower(),'Error'.lower()) #Error

    def test_3or_more_purchase_2_countries1(self):
        credit.purchase(10,4,3,'Canada')
        credit.purchase(10,5,3,'USA')
        self.assertEqual(credit.amount_owed(6,3),70)

    def test_3or_more_purchase_2_countries2(self):
        credit.purchase(10,4,3,'Canada')
        credit.purchase(10,5,3,'Canada')
        print('should be 70',credit.amount_owed(6,3))
        self.assertEqual(credit.amount_owed(6,3),70)

    def test_3or_more_purchase_2_countries3(self):
        credit.purchase(10,4,3,'Canada')
        credit.purchase(10,5,3,'USA')
        credit.purchase(10,6,3,'Canada')
        print('should be 80',credit.amount_owed(6,3))
        self.assertEqual(credit.amount_owed(6,3),80)


if __name__ == '__main__':
    unittest.main()
