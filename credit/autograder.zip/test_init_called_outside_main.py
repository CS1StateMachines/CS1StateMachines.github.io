import unittest
#import pep8  # from the current directory
import credit
import importlib
import sys

class Test_init_called_outside_main(unittest.TestCase):

    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])

    def test_purchase_without_init(self):
       credit.purchase(10,1,1,'Canada')

if __name__ == '__main__':
    unittest.main()
