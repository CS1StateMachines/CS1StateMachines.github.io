import unittest
#import pep8  # from the current directory
import credit
import sys
import importlib

class TestMultiplePurchaseSameMonthInterest(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')
        credit.purchase(30, 2,3,'Canada')
        credit.purchase(40,4,3,'Canada')
    def test_balance_updated_same_day(self):
        self.assertEqual(credit.amount_owed(4,3),70)

    def test_no_interest_purchase_month(self):
        self.assertEqual(credit.amount_owed(31,3),70)

    def test_no_interest_billing_month(self):
        self.assertEqual(credit.amount_owed(30,4),70)
    def test_interest_after_billing_month(self):
        self.assertAlmostEqual(credit.amount_owed(1,5),70*1.05)
    def test_compound_interest(self):
        self.assertAlmostEqual(credit.amount_owed(1,6),70*1.05*1.05)

class TestMultiplePurchaseDiffMonthsInterest(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')
        credit.purchase(30, 2,3,'Canada')
        credit.purchase(40,4,4,'Canada')
    def test_balance_updated_right_after_purchase(self):
        self.assertEqual(credit.amount_owed(4,4),70)
    def test_both_interest_free(self):
        self.assertEqual(credit.amount_owed(30,4),70)
    def test_first_purchase_interest1(self):
        self.assertEqual(credit.amount_owed(1,5),30*1.05+40)
    def test_first_purchase_interest2(self):
        self.assertEqual(credit.amount_owed(31,5),30*1.05+40)
    def test_first_purchase_compound_interest_sec_purchase_interest(self):
        self.assertEqual(credit.amount_owed(1,6),30*1.05*1.05+40*1.05)

class TestMultiplePurchasePayments(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')
        credit.purchase(50, 2,3,'Canada')
        credit.purchase(50,4,4,'Canada')

    def test_no_interest_payment_smaller_than_purchase(self):
        credit.pay_bill(30,5,4)
        self.assertAlmostEqual(credit.amount_owed(5,4),70)

    def test_no_interest_payment_larger_than_purchase(self):
        credit.pay_bill(70,5,4)
        self.assertAlmostEqual(credit.amount_owed(5,4),30)

    def test_payment_toward_first_payment(self):
        credit.pay_bill(30,5,4)
        self.assertEqual(credit.amount_owed(1,5),20*1.05+50)
        
    def test_payments_toward_interest_accruing_purchases(self):
        credit.pay_bill(30,5,4)
        credit.pay_bill(10,2,5)
        self.assertEqual(credit.amount_owed(1,6),50*1.05+(20*1.05-10)*1.05)

    def test_payment_towards_compounded_interest(self):
        credit.pay_bill(30,5,4)
        credit.pay_bill(10,2,5)
        credit.pay_bill(10,2,6)
        self.assertEqual(credit.amount_owed(3,7),50*1.05*1.05+((20*1.05-10)*1.05-10)*1.05)

class TestMultiplePurchasePaymentMonthGap(unittest.TestCase):
    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('NOTE: initialize is called something else')
        credit.purchase(40,2,3,'Canada')
        credit.purchase(50,4,5,'Canada')
    def test_payment_to_interest_incurring(self):
        credit.pay_bill(10,5,5)
        self.assertEqual(credit.amount_owed(1,6),(40*1.05-10)*1.05+50)
    def test_payment_can_clear_balance(self):
        credit.pay_bill(10,5,5)
        credit.pay_bill(83.6,2,6)
        print(credit.amount_owed(3,6))
        self.assertEqual(credit.amount_owed(3,6),0)

if __name__ == '__main__':
    unittest.main()
