import unittest
#import pep8  # from the current directory
import credit
import importlib
import sys

class Test_date_same_or_later(unittest.TestCase):

    def setUp(self):
        credit = importlib.reload(sys.modules['credit'])
        try:
            credit.initialize()
        except:
            print('initialize is called something else')

    def test_same_date_month(self):
        self.assertTrue(credit.date_same_or_later(1,1,1,1))
    def test_diff_day_diff_month1(self):
        ''' month1 later that month2'''
        self.assertTrue(credit.date_same_or_later(1,2,10,1))
    def test_diff_day_diff_month2(self):
        '''month1 not later than month2'''
        self.assertFalse(credit.date_same_or_later(10,1,1,2))
    def test_diff_day_diff_month3(self):
        '''date1 later than date2'''
        self.assertTrue(credit.date_same_or_later(12,2,11,1))
    def test_diff_day_diff_month4(self):
        self.assertFalse(credit.date_same_or_later(11,1,12,2))


    def test_same_month_diff_day1(self):
        self.assertTrue(credit.date_same_or_later(12,2,11,2))
    def test_same_month_diff_day2(self):
        self.assertFalse(credit.date_same_or_later(11,2,12,2))

    def test_diff_month_same_day1(self):
        self.assertTrue(credit.date_same_or_later(11,2,11,1))
    def test_diff_month_same_day2(self):
        self.assertFalse(credit.date_same_or_later(11,1,11,2))

if __name__ == '__main__':
    unittest.main()
