import unittest
import workweek

class TestCase3(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        # Test cases for sleep(), rewritten from starter code.
        workweek.sleep(200)
        assert workweek.get_hours_left() == workweek.HOURS_IN_WEEK


if __name__ == '__main__':
    unittest.main()
