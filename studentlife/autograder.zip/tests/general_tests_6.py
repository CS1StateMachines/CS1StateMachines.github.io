import unittest
import workweek

class TestCase6(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        # Test cases for is_alert(), from Blackboard.
        assert not workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
