import unittest
import workweek

class TestCase18(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        assert workweek.get_knol_amount() == 0
    

if __name__ == '__main__':
    unittest.main()
