import unittest
import workweek

class TestCase2(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        # Test cases for sleep(), rewritten from starter code.
        workweek.sleep(5)
        workweek.sleep(2)
        workweek.sleep(10)
        assert workweek.get_hours_left() == workweek.HOURS_IN_WEEK - 17 


if __name__ == '__main__':
    unittest.main()
