import unittest
import workweek

class TestCase9(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.sleep(4)
        workweek.attend_lecture("CSC", 6)
        assert workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
