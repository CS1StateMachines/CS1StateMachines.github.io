import unittest
import workweek

class TestCase16(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.drink_coffee()
        workweek.attend_lecture("CSC", 2)
        workweek.drink_coffee()
        assert not workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
