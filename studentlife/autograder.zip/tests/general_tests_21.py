import unittest
import workweek

class TestCase21(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.sleep(4)
        workweek.attend_lecture("csc", 4)
        assert workweek.get_hours_left() == workweek.HOURS_IN_WEEK - 8 and workweek.get_knol_amount() == 0


if __name__ == '__main__':
    unittest.main()
