import unittest
import workweek

class TestCase10(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.sleep(2)
        workweek.attend_lecture("CSC", 8)
        workweek.drink_coffee()
        assert workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
