import unittest
import workweek

class TestCase11(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.sleep(2)
        workweek.attend_lecture("CSC", 7)
        workweek.drink_coffee()
        workweek.attend_lecture("CSC", 1)
        assert not workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
