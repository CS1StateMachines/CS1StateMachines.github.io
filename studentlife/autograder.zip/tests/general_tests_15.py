import unittest
import workweek

class TestCase15(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.drink_coffee()
        workweek.attend_lecture("CSC", 3)
        workweek.drink_coffee()
        assert workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
