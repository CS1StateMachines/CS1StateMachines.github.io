import unittest
import workweek

class TestCase20(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.sleep(workweek.get_hours_left() - 9)
        workweek.attend_lecture("CSC", 10)
        assert workweek.get_hours_left() == 9 and workweek.get_knol_amount() == 0


if __name__ == '__main__':
    unittest.main()
