import unittest
import workweek

class TestCase8(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.sleep(3)
        workweek.attend_lecture("CSC", 7)
        assert not workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
