import unittest
import workweek

class TestCase17(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.drink_coffee()
        workweek.attend_lecture("CSC", 2)
        workweek.drink_coffee()
        workweek.sleep(2)
        assert not workweek.is_alert()
    

if __name__ == '__main__':
    unittest.main()
