import unittest
import workweek

class TestCase7(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        # Test cases for is_alert(), from Blackboard.
        workweek.sleep(2)
        workweek.attend_lecture("CSC", 8)
        assert not workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
