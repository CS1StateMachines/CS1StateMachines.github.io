#!/bin/sh
TESTDIR=$HOME/csc180/a1/tests
PYTHONPATH=$PYTHONPATH:.
export PYTHONPATH
#rm -f results.txt
num_fails=0
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_1.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_2.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_3.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_4.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_5.py
num_fails=`expr $num_fails + $?`
#/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_6.py
#num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_7.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_8.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_9.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_10.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_11.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_12.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_13.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_14.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_15.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_16.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_17.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_18.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_19.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_20.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_21.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_22.py
num_fails=`expr $num_fails + $?`
#/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_23.py
#num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_24.py
num_fails=`expr $num_fails + $?`
#/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_25.py
#num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_26.py
num_fails=`expr $num_fails + $?`
#/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_27.py
#num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_28.py
num_fails=`expr $num_fails + $?`
#/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_29.py
#num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_30.py
num_fails=`expr $num_fails + $?`
#/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_31.py
#num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_32.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_33.py
num_fails=`expr $num_fails + $?`
/usr/local/packages/python3/bin/python3 $TESTDIR/general_tests_34.py
num_fails=`expr $num_fails + $?`
echo "Number of failures = $num_fails"
if [ $num_fails -eq 0 ]
then
    echo "Perfect - give 4/4"
elif [ $num_fails -le 7 ]
then
    echo "Good - give 3/4"
elif [ $num_fails -le 14 ]
then
    echo "Fair - give 2/4"
elif [ $num_fails -le 21 ]
then
    echo "Poor - give 1/4"
else
    echo "Inadequate - give 0/4"
fi
rm -f a1_utests.sh
