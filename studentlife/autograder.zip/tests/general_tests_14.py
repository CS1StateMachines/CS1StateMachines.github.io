import unittest
import workweek

class TestCase14(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        # Test cases for drink_coffee(), from Blackboard.
        workweek.drink_coffee()
        workweek.attend_lecture("CSC", 4)
        workweek.drink_coffee()
        assert workweek.is_alert()


if __name__ == '__main__':
    unittest.main()
