import unittest
import workweek

class TestCase13(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        # Test cases for drink_coffee(), from Blackboard.
        workweek.drink_coffee()
        assert workweek.is_alert()  # this one is extra


if __name__ == '__main__':
    unittest.main()
