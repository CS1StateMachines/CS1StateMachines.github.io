import unittest
import workweek

class TestCase33(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.drink_coffee()
        workweek.attend_lecture("ESC", 10)
        assert workweek.get_hours_left() == workweek.HOURS_IN_WEEK - 10 and workweek.get_knol_amount() == 20


if __name__ == '__main__':
    unittest.main()
