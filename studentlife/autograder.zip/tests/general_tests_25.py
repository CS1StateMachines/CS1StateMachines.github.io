import unittest
import workweek

class TestCase25(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.attend_lecture("ESC", 1)
        assert workweek.get_hours_left() == workweek.HOURS_IN_WEEK - 1 and workweek.get_knol_amount() == 1


if __name__ == '__main__':
    unittest.main()
