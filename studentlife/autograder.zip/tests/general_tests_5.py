import unittest
import workweek

class TestCase5(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        # Test cases for knol_per_hour(), from Blackboard.
        assert workweek.knols_per_hour("CSC", True) == 4
        assert workweek.knols_per_hour("CSC", False) == 2
        assert workweek.knols_per_hour("MAT", True) == 2
        assert workweek.knols_per_hour("MAT", False) == 1
        assert workweek.knols_per_hour("PHY", True) == 2
        assert workweek.knols_per_hour("PHY", False) == 1
        assert workweek.knols_per_hour("ESC", True) == 2
        assert workweek.knols_per_hour("ESC", False) == 1
        assert workweek.knols_per_hour("CIV", True) == 2
        assert workweek.knols_per_hour("CIV", False) == 1
        assert workweek.knols_per_hour("csc", True) == 0
        assert workweek.knols_per_hour("csc", False) == 0
        assert workweek.knols_per_hour("a1", True) == 0
        assert workweek.knols_per_hour("a1", False) == 0
    

if __name__ == '__main__':
    unittest.main()
