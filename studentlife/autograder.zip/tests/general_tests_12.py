import unittest
import workweek

class TestCase12(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):

        workweek.sleep(2)
        workweek.attend_lecture("CSC", 6)
        workweek.drink_coffee()
        workweek.attend_lecture("CSC", 2)
        assert not workweek.is_alert()
    

if __name__ == '__main__':
    unittest.main()
