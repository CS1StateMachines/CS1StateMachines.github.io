import unittest
import workweek

class TestCases(unittest.TestCase):

    def setUp(self):
        pass

    def test_1(self):
        workweek.sleep(8)                   # sleep from 12AM to 8AM on Monday
        workweek.attend_lecture("CSC", 2)   # attend the CSC lecture for 2 hours,
                                   # gain 2*4 = 8 knols
        workweek.attend_lecture("MAT", 30)  # attend the MAT lecture for 30 hours,
                                   # gain 30*2 = 60 knols (note that since the
                                   # student was alert at the start of the
                                   # lecture, they gain two knols per hour for
                                   # the entire 30 hours)
        self.assertTrue(workweek.get_knol_amount() == 68)    # should print 68
        self.assertTrue(workweek.get_hours_left() == 73)     # should print 73 (24 * 5 - 7 - 40)


if __name__ == '__main__':
    unittest.main()
